using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

[System.Serializable]
public struct TracingPair
{
    public int fromIndex;
    public int toIndex;
}

public class LetterTracer : MonoBehaviour
{
    public Transform[] checkpoints; // Assign all checkpoints in order
    public TracingPair[] tracingPairs; // Specify pairs in Inspector for the letter
    public float checkpointRadius = 0.5f;
    public float glowSpeed = 2f;
    public Transform rocket; // Assign your rocket GameObject here
    public AudioSource successSound; // Sound for correct tracing
    public AudioSource errorSound;   // Sound for incorrect tracing
    public TMP_Text debugText;       // Assign your TextMeshProUGUI in Inspector

    private int currentPair = 0;
    private bool isTracing = false;
    private bool tracingComplete = false;

    private float minScale = 0.15f;
    private float maxScale = 0.2f;

    private Vector3 lastRocketPosition;
    private bool successDuringTrace = false;

    void Start()
    {
        foreach (Transform cp in checkpoints)
            cp.localScale = Vector3.one * minScale;

        if (rocket != null)
        {
            rocket.gameObject.SetActive(false);
            var trail = rocket.GetComponent<TrailRenderer>();
            if (trail != null)
                trail.Clear();
        }

        LogToDebug("Connect the glowing stars through your mouse in sequential direction");
        StartCoroutine(GlowCheckpoints());
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !tracingComplete)
        {
            isTracing = true;
            successDuringTrace = false;
            LogToDebug("Connect the glowing stars through your mouse in sequential direction");

            if (rocket != null)
            {
                rocket.gameObject.SetActive(true);

                Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                worldPos.z = 0;
                rocket.position = worldPos;
                lastRocketPosition = worldPos;

                var trail = rocket.GetComponent<TrailRenderer>();
                if (trail != null)
                    trail.Clear();
            }
        }
        else if (Input.GetMouseButton(0) && isTracing && !tracingComplete && tracingPairs.Length > 0)
        {
            Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            worldPos.z = 0;

            if (rocket != null)
            {
                rocket.position = worldPos;

                Vector3 moveDir = rocket.position - lastRocketPosition;
                if (moveDir.sqrMagnitude > 0.0001f)
                {
                    float angle = Mathf.Atan2(moveDir.y, moveDir.x) * Mathf.Rad2Deg;
                    rocket.rotation = Quaternion.Euler(0, 0, angle - 90f);
                }
                lastRocketPosition = rocket.position;
            }

            // Dynamic pair tracing logic
            if (currentPair < tracingPairs.Length)
            {
                int fromIdx = tracingPairs[currentPair].fromIndex;
                int toIdx = tracingPairs[currentPair].toIndex;

                float dist = Vector3.Distance(worldPos, checkpoints[toIdx].position);
                if (dist < checkpointRadius)
                {
                    LogToDebug("Yay, good job, now connect other stars");

                    checkpoints[fromIdx].localScale = Vector3.one * maxScale;
                    checkpoints[toIdx].localScale = Vector3.one * maxScale;

                    if (successSound != null)
                        successSound.Play();

                    successDuringTrace = true;
                    currentPair++;

                    if (currentPair == tracingPairs.Length)
                    {
                        tracingComplete = true;
                        isTracing = false;
                        LogToDebug("Yay, you have successfully drawn the alphabet");

                        if (rocket != null)
                            rocket.gameObject.SetActive(false);
                    }
                }
            }
        }
        else if (Input.GetMouseButtonUp(0) && isTracing && !tracingComplete)
        {
            isTracing = false;

            if (!successDuringTrace)
            {
                LogToDebug("Try again, connect the glowing stars");
                if (errorSound != null)
                    errorSound.Play();
            }

            if (rocket != null)
                rocket.gameObject.SetActive(false);
        }
    }

    IEnumerator GlowCheckpoints()
    {
        while (true)
        {
            float t = (Mathf.Sin(Time.time * glowSpeed) + 1f) / 2f;
            float scale = Mathf.Lerp(minScale, maxScale, t);

            for (int i = 0; i < checkpoints.Length; i++)
            {
                if (tracingComplete)
                {
                    checkpoints[i].localScale = Vector3.one * maxScale;
                }
                else if (currentPair < tracingPairs.Length)
                {
                    int fromIdx = tracingPairs[currentPair].fromIndex;
                    int toIdx = tracingPairs[currentPair].toIndex;

                    if (i == fromIdx || i == toIdx)
                        checkpoints[i].localScale = Vector3.one * scale;
                    else if (PairAlreadyTraced(i))
                        checkpoints[i].localScale = Vector3.one * maxScale;
                    else
                        checkpoints[i].localScale = Vector3.one * minScale;
                }
                else
                {
                    checkpoints[i].localScale = Vector3.one * minScale;
                }
            }

            yield return null;
        }
    }

    // Helper to check if a checkpoint has already been traced in any completed pair
    private bool PairAlreadyTraced(int idx)
    {
        for (int p = 0; p < currentPair; p++)
        {
            if (tracingPairs[p].fromIndex == idx || tracingPairs[p].toIndex == idx)
                return true;
        }
        return false;
    }

    // Helper to log both to Console and TMP text
    private void LogToDebug(string message)
    {
        Debug.Log(message);
        if (debugText != null)
            debugText.text = message;
    }
}
